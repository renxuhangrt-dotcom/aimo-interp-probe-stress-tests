"""Artifact loading, hidden-state extraction, and linear-probe scoring.

This module implements the inference half of the trained-probe baseline. The
pipeline for each problem is:

1. **Load an artifact** for the requested ``model_id`` (a pretrained probe
   ensemble exported by the training repo). See :func:`_load_artifact`.
2. **Encode the problem** by running one forward pass of the offline language
   model and reading the final prompt-token representation at the probe's
   required layer or layers. See
   :func:`_encode_problem`.
3. **Score the probes** by computing each linear probe's margin against that
   vector and averaging them. Non-negative mean margin => "robust". See
   :func:`mean_ensemble_margin`.

If no artifact is found for a model, the method degrades gracefully and predicts
``False`` for every problem, so the solution still builds and runs.
"""

from __future__ import annotations

import pickle
import re
import torch
import numpy as np

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any
from transformers import AutoModelForCausalLM, AutoTokenizer


# Filenames/locations searched for a probe artifact, relative to this file.
PICKLE_ARTIFACT_NAME = "probe_artifact.pkl"  # preferred ensemble format
NPZ_ARTIFACT_NAME = "probe_artifact.npz"  # legacy single-probe fallback
MODEL_ARTIFACT_DIR = "probe_artifacts"  # dir holding per-model artifacts
# Supported artifact strategies.
RECOMMENDED_STRATEGY = "best_layer_mean_margin"
FIXED_MULTILAYER_STRATEGY = "fixed_multilayer_majority_vote"
# RANDOMIZATION groups are negative controls used to detect probe memorisation.
# They must never vote in the production inference ensemble.
INFERENCE_CONTROL_TASK = "NONE"


@dataclass(frozen=True)
class ProbeArtifact:
    """A loaded probe artifact plus the metadata needed to run it.

    ``kind`` is ``"pickle"`` for the probe ensemble format or ``"npz"`` for the
    legacy single-probe format; it selects the scoring path downstream.
    """

    model_id: str  # HF model id the probe was trained against
    system_prompt: str  # prompt prefix used when the probe was trained
    data: dict[str, Any]  # raw artifact payload (schema depends on kind)
    kind: str


# ---------------------------------------------------------------------------
# Artifact loading
# ---------------------------------------------------------------------------


def _safe_model_id(model_id: str) -> str:
    """Turn a HF model id into a filesystem-safe token.

    e.g. ``"Qwen/Qwen3-8B"`` -> ``"Qwen_Qwen3-8B"`` so it can be used as a
    per-model artifact filename.
    """
    return re.sub(r"[^A-Za-z0-9._-]+", "_", model_id).strip("_")


def _artifact_candidates(model_id: str) -> list[Path]:
    """Return artifact paths to try, most specific first.

    A model-specific artifact (``probe_artifacts/<safe-id>.pkl``) wins over a
    generic one, letting a single submission ship probes for several models.
    """
    solution_dir = Path(__file__).resolve().parent
    safe_model_id = _safe_model_id(model_id)
    candidates = []
    # 1. Per-model artifacts named after the (sanitized) model id.
    if safe_model_id:
        candidates.extend(
            [
                solution_dir / MODEL_ARTIFACT_DIR / f"{safe_model_id}.pkl",
                solution_dir / MODEL_ARTIFACT_DIR / f"{safe_model_id}.npz",
            ]
        )
    # 2. Generic artifacts, checked next to solution.py and in the artifact dir.
    candidates.extend(
        [
            solution_dir / PICKLE_ARTIFACT_NAME,
            solution_dir / MODEL_ARTIFACT_DIR / PICKLE_ARTIFACT_NAME,
            solution_dir / NPZ_ARTIFACT_NAME,
        ]
    )
    return candidates


def _load_artifact(model_id: str) -> ProbeArtifact | None:
    """Load the first existing candidate artifact, or ``None`` if none exist."""
    path = next(
        (candidate for candidate in _artifact_candidates(model_id) if candidate.is_file()),
        None,
    )
    if path is None:
        return None
    # Dispatch on extension: .pkl is the ensemble format, everything else npz.
    return load_pickle_artifact(path) if path.suffix == ".pkl" else _load_npz_artifact(path)


def load_pickle_artifact(path: Path) -> ProbeArtifact:
    """Load and validate a schema-v2 or schema-v3 probe-ensemble pickle.

    Raises ``RuntimeError`` on any schema mismatch so a malformed artifact fails
    loudly instead of silently producing garbage predictions.
    """
    with path.open("rb") as handle:
        data = pickle.load(handle)

    # Validate the artifact shape before trusting any of its contents.
    if not isinstance(data, dict):
        raise RuntimeError(f"{path.name} must contain a dictionary artifact")
    schema_version = data.get("schema_version")
    if schema_version not in {2, 3}:
        raise RuntimeError(
            f"{path.name} has unsupported schema_version {schema_version!r}"
        )
    expected_type = (
        "all_folds_layers_seed_probe_ensemble"
        if schema_version == 2
        else "fixed_multilayer_vote_probe_ensemble"
    )
    if data.get("artifact_type") != expected_type:
        raise RuntimeError(
            f"{path.name} has unsupported artifact_type {data.get('artifact_type')!r}"
        )
    if not data.get("groups"):
        raise RuntimeError(f"{path.name} contains no probe groups")
    if schema_version == 2 and "best_layer_index" not in data:
        raise RuntimeError(f"{path.name} is missing best_layer_index")

    # Fail closed on ambiguous group metadata. Silently averaging randomized
    # control-task probes into production predictions can collapse the method
    # to a constant classifier while still producing syntactically valid output.
    _eligible_inference_groups(data)

    # If a strategy is recorded it must match the artifact schema.
    strategy = data.get("recommended_strategy") or {}
    expected_strategy = (
        RECOMMENDED_STRATEGY if schema_version == 2 else FIXED_MULTILAYER_STRATEGY
    )
    if strategy.get("name") != expected_strategy:
        raise RuntimeError(f"{path.name} recommends unsupported strategy {strategy.get('name')!r}")
    if schema_version == 3:
        layers = strategy.get("layers")
        if (
            not isinstance(layers, list)
            or not layers
            or len(layers) % 2 != 1
            or len(set(layers)) != len(layers)
            or not all(isinstance(layer, int) for layer in layers)
        ):
            raise RuntimeError(
                f"{path.name} must declare an odd, unique integer layer list"
            )
        for group_index, group in enumerate(_eligible_inference_groups(data)):
            probes = group.get("probes")
            if not isinstance(probes, dict):
                raise RuntimeError(f"group {group_index} contains no probes mapping")
            missing_layers = [
                layer
                for layer in layers
                if layer not in probes and str(layer) not in probes
            ]
            if missing_layers:
                raise RuntimeError(
                    f"group {group_index} is missing multilayer probes {missing_layers}"
                )

    return ProbeArtifact(
        model_id=str(data.get("model_id") or ""),
        system_prompt=str(data.get("system_prompt") or ""),
        data=data,
        kind="pickle",
    )


def _eligible_inference_groups(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Return only real-label groups that are allowed to vote at inference.

    Every group must explicitly declare ``control_task``. This prevents older
    or malformed artifacts from being interpreted optimistically. Groups such
    as ``RANDOMIZATION`` remain useful for scientific controls but are excluded
    from the deployed ensemble.
    """
    groups = data.get("groups")
    if not isinstance(groups, list) or not groups:
        raise RuntimeError("probe artifact contains no probe groups")

    missing = [index for index, group in enumerate(groups) if "control_task" not in group]
    if missing:
        raise RuntimeError(
            "probe groups are missing control_task metadata at indices "
            + ", ".join(map(str, missing))
        )

    eligible = [
        group for group in groups if group.get("control_task") == INFERENCE_CONTROL_TASK
    ]
    if not eligible:
        raise RuntimeError(
            f"artifact contains no {INFERENCE_CONTROL_TASK!r} inference groups"
        )
    return eligible


def _load_npz_artifact(path: Path) -> ProbeArtifact:
    """Load the legacy single-probe ``.npz`` format (compatibility fallback)."""
    data = np.load(path, allow_pickle=False)
    required = {"model_id", "layer_index", "weights", "bias", "threshold"}
    missing = sorted(required.difference(data.files))
    if missing:
        raise RuntimeError(f"{path.name} is missing required entries: {missing}")

    # A single probe is stored as flat weight/bias/threshold arrays.
    weights = np.asarray(data["weights"], dtype=np.float32).reshape(-1)
    if weights.size == 0:
        raise RuntimeError(f"{path.name} contains empty probe weights")

    return ProbeArtifact(
        model_id=str(_scalar(data["model_id"])),
        system_prompt=str(_scalar(data["system_prompt"])) if "system_prompt" in data.files else "",
        data={
            "layer_index": int(_scalar(data["layer_index"])),
            "weights": weights,
            "bias": float(_scalar(data["bias"])),
            "threshold": float(_scalar(data["threshold"])),
        },
        kind="npz",
    )


def _scalar(value: Any) -> Any:
    """Unwrap a 0-d numpy array to a Python scalar; pass other values through."""
    return value.item() if hasattr(value, "item") else value


def _layer_index(artifact: ProbeArtifact) -> int:
    """Resolve which model layer's hidden state the probe reads.

    For the ensemble format, prefer the strategy's ``layer_index`` and fall back
    to the globally selected ``best_layer_index``.
    """
    if artifact.kind == "pickle":
        strategy = artifact.data.get("recommended_strategy") or {}
        return int(strategy.get("layer_index", artifact.data["best_layer_index"]))
    return int(artifact.data["layer_index"])


def _required_layer_indices(artifact: ProbeArtifact) -> list[int]:
    """Return every hidden-state layer required by the deployment strategy."""
    if artifact.kind == "pickle" and artifact.data.get("schema_version") == 3:
        strategy = artifact.data.get("recommended_strategy") or {}
        return [int(layer) for layer in strategy["layers"]]
    return [_layer_index(artifact)]


# ---------------------------------------------------------------------------
# Hidden-state extraction
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def _load_model(model_id: str) -> tuple[Any, Any]:
    """Load the tokenizer and model from the offline HF cache.

    ``local_files_only=True`` is essential: the evaluation container has no
    network, so anything not already cached must fail rather than hang.
    The cache keeps the model resident across all problems in one evaluator
    batch; reloading an 8B checkpoint for every problem would dominate runtime.
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cuda":
        # Prefer bfloat16 where supported, else float16; both halve memory use.
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    else:
        dtype = torch.float32

    tokenizer = AutoTokenizer.from_pretrained(model_id, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        dtype=dtype,
        local_files_only=True,
    )
    model.to(device)
    model.eval()  # disable dropout etc. for deterministic representations
    return tokenizer, model


def _build_prompt(tokenizer: Any, problem_text: str, system_prompt: str) -> str:
    """Format the problem exactly as it was formatted during probe training.

    Uses the tokenizer's chat template when a system prompt is present (so the
    encoding matches an instruct model's expected format), and falls back to a
    plain concatenation if templating is unavailable or fails.
    """
    if system_prompt and hasattr(tokenizer, "apply_chat_template"):
        try:
            return tokenizer.apply_chat_template(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": problem_text},
                ],
                tokenize=False,
                add_generation_prompt=True,
            )
        except Exception:
            # Some tokenizers lack a usable template; degrade to plain text.
            pass
    return f"{system_prompt}\n\n{problem_text}" if system_prompt else problem_text


def _encode_problem(problem_text: str, artifact: ProbeArtifact) -> Any:
    """Run one forward pass and return the required hidden-state representation.

    Schema-v2/single-probe artifacts receive one float32 vector. Schema-v3
    multi-layer artifacts receive ``{layer_index: vector}``. Both forms use the
    final prompt token, mirroring training.
    """
    tokenizer, model = _load_model(artifact.model_id)
    prompt = _build_prompt(tokenizer, problem_text, artifact.system_prompt)
    model_inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    model_inputs = {name: value.to(model.device) for name, value in model_inputs.items()}

    # No gradients or KV cache needed; we only want the hidden states.
    with torch.no_grad():
        output = model(
            **model_inputs,
            output_hidden_states=True,
            return_dict=True,
            use_cache=False,
        )

    hidden_states = output.hidden_states
    if hidden_states is None:
        raise RuntimeError("model forward pass returned no hidden states")

    # hidden_states is a tuple of (num_layers + 1) tensors, each
    # (batch, seq_len, hidden_dim). Validate every requested layer.
    layer_indices = _required_layer_indices(artifact)
    for layer_index in layer_indices:
        if not -len(hidden_states) <= layer_index < len(hidden_states):
            raise RuntimeError(
                f"probe layer {layer_index} is outside model hidden-state range "
                f"0..{len(hidden_states) - 1}"
            )
    vectors = {
        layer_index: hidden_states[layer_index][0, -1, :]
        .detach()
        .float()
        .cpu()
        .numpy()
        for layer_index in layer_indices
    }
    if artifact.kind == "pickle" and artifact.data.get("schema_version") == 3:
        return vectors
    return vectors[layer_indices[0]]


# ---------------------------------------------------------------------------
# Probe scoring
# ---------------------------------------------------------------------------


def _single_probe_margin(vector: Any, artifact: ProbeArtifact) -> float:
    """Signed margin for the legacy single-probe (.npz) format.

    ``margin = weights . vector + bias - threshold``; ``>= 0`` means "robust".
    """
    weights = np.asarray(artifact.data["weights"], dtype=np.float32).reshape(-1)
    if vector.shape != weights.shape:
        raise RuntimeError(
            f"probe dimension mismatch: got {vector.shape[0]}, expected {weights.shape[0]}"
        )
    score = float(np.dot(vector, weights) + float(artifact.data["bias"]))
    return score - float(artifact.data["threshold"])


def mean_ensemble_margin(vector: Any, artifact: ProbeArtifact) -> float:
    """Average signed margin across every probe in the ensemble.

    The ensemble spans groups (e.g. cross-validation folds), each holding a
    stack of per-seed probes for the chosen layer. We compute
    ``weights @ vector + bias - threshold`` for all of them and return the mean;
    a non-negative mean is the "robust" decision.
    """
    layer_index = _layer_index(artifact)
    margins = []
    for group in _eligible_inference_groups(artifact.data):
        probes = group.get("probes", {})
        # Layer keys may be stored as ints or strings; accept either.
        probe = probes.get(layer_index, probes.get(str(layer_index)))
        if probe is None:
            continue

        # weights: (n_seeds, hidden_dim); normalize a 1-D probe to 2-D.
        weights = np.asarray(probe["weights"], dtype=np.float32)
        if weights.ndim == 1:
            weights = weights.reshape(1, -1)
        if weights.ndim != 2 or weights.shape[1] != vector.shape[0]:
            raise RuntimeError(
                f"probe dimension mismatch: got {vector.shape[0]}, expected {weights.shape[-1]}"
            )

        # bias/threshold are per-seed vectors aligned with weights' first axis.
        bias = np.asarray(probe["bias"], dtype=np.float32).reshape(-1)
        threshold = np.asarray(probe["threshold"], dtype=np.float32).reshape(-1)
        if bias.size != weights.shape[0] or threshold.size != weights.shape[0]:
            raise RuntimeError("probe ensemble arrays have inconsistent seed dimensions")

        # One margin per seed in this group; collect across all groups.
        margins.extend((weights @ vector + bias - threshold).astype(float).tolist())

    if not margins:
        raise RuntimeError(f"artifact contains no probes for layer {layer_index}")
    # float64 mean to avoid accumulation error across many seeds/folds.
    return float(np.mean(np.asarray(margins, dtype=np.float64)))


def multilayer_positive_vote_fraction(
    vectors: dict[int, Any], artifact: ProbeArtifact
) -> float:
    """Return the equal-weight positive-vote fraction for a schema-v3 artifact."""
    layers = _required_layer_indices(artifact)
    missing_vectors = [layer for layer in layers if layer not in vectors]
    if missing_vectors:
        raise RuntimeError(f"encoded representations are missing layers {missing_vectors}")
    votes: list[bool] = []
    for group in _eligible_inference_groups(artifact.data):
        probes = group.get("probes", {})
        for layer_index in layers:
            probe = probes.get(layer_index, probes.get(str(layer_index)))
            if probe is None:
                raise RuntimeError(f"artifact group is missing probe layer {layer_index}")
            vector = np.asarray(vectors[layer_index], dtype=np.float32).reshape(-1)
            weights = np.asarray(probe["weights"], dtype=np.float32)
            if weights.ndim == 1:
                weights = weights.reshape(1, -1)
            if weights.ndim != 2 or weights.shape[1] != vector.shape[0]:
                raise RuntimeError(
                    f"probe dimension mismatch at layer {layer_index}: "
                    f"got {vector.shape[0]}, expected {weights.shape[-1]}"
                )
            bias = np.asarray(probe["bias"], dtype=np.float32).reshape(-1)
            threshold = np.asarray(probe["threshold"], dtype=np.float32).reshape(-1)
            if bias.size != weights.shape[0] or threshold.size != weights.shape[0]:
                raise RuntimeError("probe ensemble arrays have inconsistent seed dimensions")
            margins = weights @ vector + bias - threshold
            votes.extend((margins >= 0.0).tolist())
    if not votes or len(votes) % 2 != 1:
        raise RuntimeError(f"multilayer ensemble must contain an odd number of votes, got {len(votes)}")
    return float(np.mean(np.asarray(votes, dtype=np.float64)))


def _predict_problem(problem_text: str, artifact: ProbeArtifact) -> bool:
    """Encode one problem and turn its probe margin into a robustness bool."""
    return bool(_predict_problem_margin(problem_text, artifact) >= 0.0)


def _predict_problem_margin(problem_text: str, artifact: ProbeArtifact) -> float:
    """Return the signed deployment margin for one problem."""
    encoded = _encode_problem(problem_text, artifact)
    if artifact.kind == "pickle" and artifact.data.get("schema_version") == 3:
        # Convert a vote fraction to a signed score around the fixed 50% cutoff.
        return multilayer_positive_vote_fraction(encoded, artifact) - 0.5
    vector = np.asarray(encoded, dtype=np.float32)
    return (
        mean_ensemble_margin(vector, artifact)
        if artifact.kind == "pickle"
        else _single_probe_margin(vector, artifact)
    )


def predict_robustness(model_id: str, problem_texts: list[str]) -> list[bool]:
    """Return one robustness prediction for each problem text.

    Loads the artifact once, then scores every problem. Missing artifacts fail
    loudly: a silent all-False fallback can look like a valid scientific result
    while actually being only a constant baseline.
    """
    artifact = _load_artifact(model_id)
    if artifact is None:
        raise RuntimeError(f"no probe artifact found for model {model_id!r}")

    margins = [_predict_problem_margin(problem_text, artifact) for problem_text in problem_texts]
    predictions = [bool(margin >= 0.0) for margin in margins]
    if margins:
        layers = _required_layer_indices(artifact)
        print(
            "[probe diagnostics] "
            f"layers={layers} "
            f"eligible_groups={len(_eligible_inference_groups(artifact.data))} "
            f"cases={len(margins)} positives={sum(predictions)} "
            f"margin_min={min(margins):.6g} margin_mean={np.mean(margins):.6g} "
            f"margin_max={max(margins):.6g}"
        )
    return predictions
